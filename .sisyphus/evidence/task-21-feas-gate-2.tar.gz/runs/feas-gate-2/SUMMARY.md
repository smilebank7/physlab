# Eureka Franka Run

- best_iteration: 3
- best_success_rate: 1.000000

iteration | success_rate | wall_clock | reward_signature
0 | 0.0000 | 0.96s | 
1 | 0.0000 | 0.67s | 
2 | 0.0000 | 0.66s | 
3 | 1.0000 | 7.23s | 
4 | 0.0000 | 0.69s | 
