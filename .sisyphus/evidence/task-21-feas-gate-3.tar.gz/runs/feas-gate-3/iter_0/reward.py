import math

import numpy as np


def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    """Dense shaped reward for the Franka pick-place anchor task.

    Observation layout (24-dim, FrankaPickTask.observe at franka_pick.py:66-84):
      [0:7]    Franka joint qpos
      [7:14]   Franka joint qvel
      [14:17]  cube world position (xyz)
      [17:21]  cube world quaternion (wxyz)
      [21:24]  target site world position (xyz)

    There is no gripper actuator and no end-effector position in obs, so
    shaping is built entirely from cube kinematics + joint velocity + action.

    Spec reward:
      r = -distance(cube, target) + 1_success
      success := cube_z > 0.5 AND distance(cube, target) < 0.1
    """
    del info  # preflight passes {"step_count": 0}; obs is the source of truth.

    o = np.asarray(obs, dtype=np.float64).reshape(-1)
    a = np.asarray(action, dtype=np.float64).reshape(-1)
    if o.size < 24:
        o = np.concatenate([o, np.zeros(24 - o.size, dtype=np.float64)])
    if a.size < 7:
        a = np.concatenate([a, np.zeros(7 - a.size, dtype=np.float64)])

    qvel = o[7:14]
    cube_pos = o[14:17]
    cube_quat = o[17:21]
    target_pos = o[21:24]

    # ---- Core scalars (eps keeps gradients finite at zero distance) ----
    delta = cube_pos - target_pos
    dist = math.sqrt(float(np.dot(delta, delta)) + 1e-12)
    horiz_dist = math.sqrt(float(delta[0] * delta[0] + delta[1] * delta[1]) + 1e-12)
    cube_z = float(cube_pos[2])

    # Reset distributions (franka_pick.py:46-49): cube_z ~ 0.405..0.455,
    # target_z ~ 0.42..0.47. Use a conservative ramp for the lift term.
    table_z = 0.40
    lift_goal = 0.50

    success = (cube_z > lift_goal) and (dist < 0.10)

    # ---- 1. Spec base term: -distance + sparse success indicator ----
    reward = -dist + (1.0 if success else 0.0)

    # ---- 2. Lift shaping: ramp from rest height to success threshold ----
    lift_norm = (cube_z - table_z) / max(lift_goal - table_z, 1e-6)
    lift_clipped = min(max(lift_norm, 0.0), 1.5)
    reward += 0.6 * math.tanh(2.0 * lift_clipped)

    # ---- 3. Coarse approach (dense gradient across the workspace) ----
    reward += 0.4 * (1.0 - math.tanh(3.0 * dist))

    # ---- 4. Fine approach (curriculum: only credited once airborne) ----
    if cube_z > 0.45:
        reward += 0.5 * (1.0 - math.tanh(10.0 * dist))

    # ---- 5. Horizontal alignment (helps the carry phase) ----
    reward += 0.2 * (1.0 - math.tanh(5.0 * horiz_dist))

    # ---- 6. Upright orientation: |qw| / |q| -> 1 for identity quat ----
    qnorm_sq = float(np.dot(cube_quat, cube_quat))
    if qnorm_sq > 1e-8:
        upright = abs(float(cube_quat[0])) / math.sqrt(qnorm_sq)
        reward += 0.1 * upright

    # ---- 7. Smoothness penalties (small; prevents thrashing) ----
    reward -= 0.0005 * float(np.dot(qvel, qvel))
    reward -= 0.001 * float(np.dot(a, a))

    # ---- 8. Salient terminal bonus to make the sparse signal learnable ----
    if success:
        reward += 5.0

    # ---- 9. Defensive finiteness clamp ----
    if not math.isfinite(reward):
        return -10.0
    return float(reward)