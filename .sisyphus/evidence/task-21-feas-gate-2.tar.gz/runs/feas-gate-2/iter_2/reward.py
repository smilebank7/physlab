def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    # Defensive, bounded, finite-guaranteed reward for Franka pick-place.
    # Implements the required `-distance(cube,target) + 1_success` core
    # plus dense shaping (reach / lift / place / smoothness) for learning.
    try:
        # ---- Sanitize observation ----
        o = np.asarray(obs, dtype=np.float64).flatten()
        o = np.nan_to_num(o, nan=0.0, posinf=1e3, neginf=-1e3)
        n = int(o.shape[0])

        # ---- Pull positions from info dict first (preferred, ground-truth) ----
        def _get(d, keys):
            if not isinstance(d, dict):
                return None
            for k in keys:
                if k not in d or d[k] is None:
                    continue
                try:
                    a = np.asarray(d[k], dtype=np.float64).flatten()
                    if a.size >= 3:
                        a = np.nan_to_num(a[:3], nan=0.0, posinf=1e3, neginf=-1e3)
                        return np.clip(a, -10.0, 10.0)
                except Exception:
                    continue
            return None

        cube_pos = _get(info, ('cube_pos', 'object_pos', 'obj_pos',
                               'block_pos', 'achieved_goal'))
        target_pos = _get(info, ('target_pos', 'goal_pos', 'target',
                                 'goal', 'desired_goal'))
        ee_pos = _get(info, ('ee_pos', 'eef_pos', 'gripper_pos',
                             'hand_pos', 'tcp_pos'))

        # ---- Fallback to obs slicing for the declared 24-dim Franka layout ----
        # Best-guess layout: [qpos(7), qvel(7), ee_pos(3), cube_pos(3),
        #                     target_pos(3), gripper(1)] = 24
        if n >= 24:
            if ee_pos is None:
                ee_pos = np.clip(o[14:17].copy(), -10.0, 10.0)
            if cube_pos is None:
                cube_pos = np.clip(o[17:20].copy(), -10.0, 10.0)
            if target_pos is None:
                target_pos = np.clip(o[20:23].copy(), -10.0, 10.0)

        # If we still cannot determine the required positions, bail safely.
        if cube_pos is None or target_pos is None:
            return 0.0

        cube_pos = np.asarray(cube_pos, dtype=np.float64).flatten()[:3]
        target_pos = np.asarray(target_pos, dtype=np.float64).flatten()[:3]

        # ---- Core spec: -distance(cube, target) + 1_success ----
        delta = cube_pos - target_pos
        sq = float(np.dot(delta, delta))
        distance = float(np.sqrt(sq + 1e-12))  # +eps avoids sqrt(0) gradient issues
        distance = float(min(distance, 100.0))  # hard cap, never inf

        cube_z = float(cube_pos[2])
        is_success = (cube_z > 0.5) and (distance < 0.1)
        success_bonus = 1.0 if is_success else 0.0

        reward = -distance + success_bonus

        # ---- Dense shaping (all bounded, all finite) ----
        # (a) Reach: end-effector toward cube
        if ee_pos is not None:
            ee_pos = np.asarray(ee_pos, dtype=np.float64).flatten()[:3]
            ed = ee_pos - cube_pos
            ee_dist = float(np.sqrt(float(np.dot(ed, ed)) + 1e-12))
            ee_dist = float(min(ee_dist, 100.0))
            reward += -0.5 * ee_dist
            # Smooth proximity bonus (saturates, never explodes)
            reward += 0.25 * float(np.exp(-10.0 * min(ee_dist, 5.0)))
            # Discrete grasp-ready bonus
            if ee_dist < 0.05:
                reward += 0.5

        # (b) Lift: encourage cube z-progress toward success threshold (0.5)
        lift = float(np.clip((cube_z - 0.02) / 0.5, 0.0, 1.2))
        reward += 0.5 * lift

        # (c) Place: smooth proximity bonus near target
        reward += 0.5 * float(np.exp(-10.0 * min(distance, 5.0)))

        # (d) Action smoothness (tiny penalty to discourage jitter)
        if action is not None:
            a = np.asarray(action, dtype=np.float64).flatten()
            a = np.nan_to_num(a, nan=0.0, posinf=1.0, neginf=-1.0)
            a = np.clip(a, -1.0, 1.0)
            reward += -0.001 * float(np.dot(a, a))

        # ---- Final safety: guarantee a finite, bounded float ----
        if not np.isfinite(reward):
            return 0.0
        return float(np.clip(reward, -50.0, 50.0))

    except Exception:
        # Any unexpected failure -> neutral reward, never crash the rollout.
        return 0.0