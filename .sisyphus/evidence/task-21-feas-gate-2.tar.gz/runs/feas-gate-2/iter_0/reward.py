def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    # ---- Robust extraction of world-space quantities ----
    def _get_xyz(keys, default):
        if isinstance(info, dict):
            for k in keys:
                v = info.get(k)
                if v is None:
                    continue
                arr = np.asarray(v, dtype=np.float64).reshape(-1)
                if arr.size >= 3:
                    return arr[:3]
        return default

    # Assumed 24D state-vector layout for Franka pick-place:
    #   [qpos(9), qvel(9), cube_xyz(3), target_xyz(3)]
    obs_arr = np.asarray(obs, dtype=np.float64).reshape(-1)
    cube_default   = obs_arr[18:21] if obs_arr.size >= 21 else np.zeros(3)
    target_default = obs_arr[21:24] if obs_arr.size >= 24 else np.zeros(3)

    cube_pos   = _get_xyz(["cube_pos", "object_pos", "obj_pos", "block_pos"], cube_default)
    target_pos = _get_xyz(["target_pos", "goal_pos", "goal", "target"],       target_default)
    ee_pos     = _get_xyz(["ee_pos", "eef_pos", "end_effector_pos",
                           "gripper_pos", "hand_pos"], None)

    # ---- Core geometric quantities ----
    place_dist = float(np.linalg.norm(cube_pos - target_pos))
    cube_z     = float(cube_pos[2])

    # ---- Spec-mandated base reward ----
    success = (cube_z > 0.5) and (place_dist < 0.1)
    reward  = -place_dist + (1.0 if success else 0.0)

    # ---- Dense shaping for learning ----
    # (1) Reach: pull end-effector toward cube (saturating tanh kernel)
    if ee_pos is not None:
        reach_dist = float(np.linalg.norm(ee_pos - cube_pos))
        reward += 0.5 * (1.0 - np.tanh(10.0 * reach_dist))
        if reach_dist < 0.05:
            reward += 0.2  # explicit grasp-proximity bonus

    # (2) Lift: reward cube height progress toward the 0.5 success threshold
    lift_progress = float(np.clip((cube_z - 0.03) / 0.47, 0.0, 1.0))
    reward += 0.5 * lift_progress

    # (3) Carry-to-target: dense funnel once the cube is off the table
    if cube_z > 0.1:
        reward += 0.5 * (1.0 - np.tanh(3.0 * place_dist))

    # (4) Near-success funnel: extra pull when both criteria are nearly met
    if cube_z > 0.4 and place_dist < 0.15:
        reward += 0.5

    # (5) Smoothness: small L2 action penalty for stable control
    act = np.asarray(action, dtype=np.float64).reshape(-1)
    reward -= 1e-3 * float(np.dot(act, act))

    # ---- Safety: guarantee a finite float ----
    if not np.isfinite(reward):
        return -10.0
    return float(reward)