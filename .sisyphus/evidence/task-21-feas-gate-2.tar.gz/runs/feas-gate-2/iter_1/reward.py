def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    # ---- Defensive obs parsing (prior crash was likely indexing/NaN/missing key) ----
    try:
        o = np.asarray(obs, dtype=np.float64).ravel()
    except Exception:
        o = np.zeros(24, dtype=np.float64)
    n = int(o.size)

    cube_pos = None
    target_pos = None
    ee_pos = None

    # 1) Authoritative source: info dict (most reliable when present)
    if isinstance(info, dict) and len(info) > 0:
        for k in ('cube_pos', 'object_pos', 'obj_pos', 'block_pos',
                  'cube_position', 'achieved_goal'):
            v = info.get(k)
            if v is None:
                continue
            try:
                a = np.asarray(v, dtype=np.float64).ravel()
                if a.size >= 3 and np.all(np.isfinite(a[:3])):
                    cube_pos = a[:3].copy(); break
            except Exception:
                continue
        for k in ('target_pos', 'goal_pos', 'goal', 'target',
                  'target_position', 'desired_goal'):
            v = info.get(k)
            if v is None:
                continue
            try:
                a = np.asarray(v, dtype=np.float64).ravel()
                if a.size >= 3 and np.all(np.isfinite(a[:3])):
                    target_pos = a[:3].copy(); break
            except Exception:
                continue
        for k in ('ee_pos', 'eef_pos', 'gripper_pos', 'hand_pos',
                  'tcp_pos', 'end_effector_pos'):
            v = info.get(k)
            if v is None:
                continue
            try:
                a = np.asarray(v, dtype=np.float64).ravel()
                if a.size >= 3 and np.all(np.isfinite(a[:3])):
                    ee_pos = a[:3].copy(); break
            except Exception:
                continue

    # 2) Fall back to 24-dim Franka pick-place layout:
    #    [qpos(7) | gripper(2) | qvel(7) | gripvel(2) | cube_xyz(3) | target_xyz(3)]
    if n >= 24:
        if cube_pos is None:
            c = o[18:21]
            if np.all(np.isfinite(c)):
                cube_pos = c.copy()
        if target_pos is None:
            t = o[21:24]
            if np.all(np.isfinite(t)):
                target_pos = t.copy()

    # 3) Hard defaults (only hit if obs/info both fail – keeps reward finite)
    if cube_pos is None or not np.all(np.isfinite(cube_pos)):
        cube_pos = np.array([0.5, 0.0, 0.05], dtype=np.float64)
    if target_pos is None or not np.all(np.isfinite(target_pos)):
        target_pos = np.array([0.5, 0.0, 0.5], dtype=np.float64)

    # Clamp positions to a sane workspace (prevents pathological shaping)
    cube_pos   = np.clip(cube_pos,   -5.0, 5.0)
    target_pos = np.clip(target_pos, -5.0, 5.0)
    if ee_pos is not None:
        ee_pos = np.clip(ee_pos, -5.0, 5.0)

    # ---- Distance: bounded, no division, NaN-safe ----
    diff = cube_pos - target_pos
    distance = float(np.sqrt(float(np.dot(diff, diff)) + 1e-12))
    distance = min(distance, 10.0)
    cube_z = float(cube_pos[2])

    # ---- Success criterion (exactly as specified) ----
    is_success = bool((cube_z > 0.5) and (distance < 0.1))

    # ---- Bounded dense shaping (only tanh / exp(-c*d) / squared clipped action) ----
    r_distance     = -distance                                          # primary, in [-10, 0]
    r_proximity    = float(np.exp(-3.0 * distance))                     # in (0, 1]
    cube_lift      = max(0.0, cube_z - 0.05)
    r_lift         = float(np.tanh(4.0 * cube_lift))                    # in [0, 1)
    r_lifted_close = r_lift * float(np.exp(-3.0 * distance))            # in [0, 1)

    r_reach = 0.0
    if ee_pos is not None:
        rd = ee_pos - cube_pos
        rd_dist = float(np.sqrt(float(np.dot(rd, rd)) + 1e-12))
        r_reach = float(np.exp(-8.0 * min(rd_dist, 10.0)))              # in (0, 1]

    try:
        a = np.asarray(action, dtype=np.float64).ravel()
        if a.size > 0 and np.all(np.isfinite(a)):
            r_action = float(np.mean(np.clip(a, -1.0, 1.0) ** 2))       # in [0, 1]
        else:
            r_action = 0.0
    except Exception:
        r_action = 0.0

    r_success = 1.0 if is_success else 0.0

    # ---- Eureka-style dense composite (matches spec primary + shaping + success bonus) ----
    reward = (
        1.0  * r_distance        # primary task signal: -distance(cube,target)
      + 1.0  * r_proximity       # smooth proximity bonus (gradient near goal)
      + 0.5  * r_lift            # encourage lifting cube off the table
      + 2.0  * r_lifted_close    # crucial pick-place coupling: lifted AND close
      + 0.3  * r_reach           # ee->cube reach (if exposed in info)
      - 0.01 * r_action          # mild control smoothness
      + 10.0 * r_success         # amplified success bonus
    )

    # ---- Final NaN/Inf guard + range clip ----
    if not np.isfinite(reward):
        return -1.0
    return float(np.clip(reward, -20.0, 20.0))