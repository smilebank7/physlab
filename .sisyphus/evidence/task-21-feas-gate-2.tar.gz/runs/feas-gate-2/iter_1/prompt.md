You are writing one dense reward function for a local MuJoCo physical AI task.

Task:
Franka pick-place anchor task. State-vector Franka pick-place target for Eureka-style reward search.

Reward signature:
reward=-distance(cube,target)+1_success; success=cube_z>0.5 and distance<0.1

Observation spec:
observation_space: ObsSpec(shape=(24,), dtype=dtype('float64'), low=None, high=None)

Action spec:
action_space: ActionSpec(shape=(7,), dtype=dtype('float64'), low=array([-1., -1., -1., -1., -1., -1., -1.]), high=array([1., 1., 1., 1., 1., 1., 1.]))

Prior attempts:
- attempt 0: metrics(mean_episode_reward=0, success_rate=0); reflection: **Iteration 0 summary (franka_pick):** The reward function itself compiled and was accepted by the training pipeline (`reward status: ok`), so the symbolic/syntactic layer is sound. However, evaluation crashed outright, meaning no rollouts produced valid success metrics — the 0% success rate reflects a hard failure, not a learning shortfall. The next attempt should focus on **diagnosing the crash before tuning shaping**: most commonly this is a tensor-shape/indexing mismatch, a NaN/Inf in a reward component (e. g. unbounded `1/distance` or `exp` term), or a missing observation key that the reward references.

Context seed:
43

Emit exactly one fenced Python code block containing:

```python
def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    ...
```

Use only numpy, math, and physlab imports. Do not perform file, network, process, or random
side effects. The reward should be shaped for learning and return a finite float.
