import math

import numpy as np


def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    """Dense reward for the Franka state-vector pick-place anchor task (seed 45).

    Observation layout (24-dim, fixed by FrankaPickTask.observe):
        obs[0:7]   -> 7 Franka joint qpos
        obs[7:14]  -> 7 Franka joint qvel
        obs[14:17] -> cube xyz (world frame)
        obs[17:21] -> cube quaternion (w, x, y, z)
        obs[21:24] -> target xyz (mocap site)

    Action: 7 joint motor commands in [-1, 1].

    Anchor (per reward_signature):
        reward = -distance(cube, target) + 1_success
        success = (cube_z > 0.5) and (distance < 0.1)

    Shaping on top of the anchor (all bounded, all finite):
      - lift_bonus      : tanh reward for cube above the table top (z=0.38)
      - threshold_bonus : sharp tanh gradient as cube crosses z=0.5
      - proximity_bonus : bounded 1/(1+k*d^2) for being near target in 3D
      - xy_bonus        : bounded 1/(1+k*xy^2) for horizontal alignment
      - action_penalty  : small L2 to discourage motor thrashing
      - vel_penalty     : small L2 on joint velocities for smoothness
      - stage_bonus     : stair-stepped milestone bonuses leading to success

    Crash defenses (iter 0/1/2 all crashed in eval — same root cause):
      * Preflight calls reward_fn(zeros(24), zeros(7), {"step_count": 0}) so
        info has NO task keys: ALL signal is derived from `obs`, never `info`.
      * NaN/Inf in obs or action -> np.nan_to_num + np.clip.
      * Short/long obs           -> reshape(-1) + pad to 24.
      * Divide-by-zero           -> every division uses 1/(1 + k*x>=0) form.
      * Unbounded exp/log        -> only math.tanh is used for shaping.
      * sqrt of small negative   -> sqrt(dist_sq + 1e-12).
      * Anything else            -> bare-except returns -1.0 (the sandbox
                                    strips builtins, so we cannot reference
                                    the `Exception` class explicitly).
    """
    try:
        # ---- Robust obs extraction ----
        obs_arr = np.asarray(obs, dtype=np.float64).reshape(-1)
        obs_arr = np.nan_to_num(obs_arr, nan=0.0, posinf=10.0, neginf=-10.0)
        if obs_arr.shape[0] < 24:
            padded = np.zeros(24, dtype=np.float64)
            padded[: obs_arr.shape[0]] = obs_arr
            obs_arr = padded

        # ---- Robust action extraction ----
        act_arr = np.asarray(action, dtype=np.float64).reshape(-1)
        act_arr = np.nan_to_num(act_arr, nan=0.0, posinf=1.0, neginf=-1.0)

        # ---- Task slices, workspace-clamped ----
        joint_vel = np.clip(obs_arr[7:14], -20.0, 20.0)
        cube_pos = np.clip(obs_arr[14:17], -5.0, 5.0)
        target_pos = np.clip(obs_arr[21:24], -5.0, 5.0)

        # ---- Core distance (anchor term) ----
        diff = cube_pos - target_pos
        dist_sq = float(np.dot(diff, diff))
        distance = float(math.sqrt(dist_sq + 1e-12))
        distance = min(distance, 10.0)

        cube_z = float(cube_pos[2])
        success = (cube_z > 0.5) and (distance < 0.1)
        success_indicator = 1.0 if success else 0.0

        # 1) Anchor reward (matches task.reward_signature exactly)
        anchor = -distance + success_indicator

        # 2) Lift bonus: cube above table top (z=0.38)
        lift = max(-1.0, min(1.0, cube_z - 0.38))
        lift_bonus = 0.5 * float(math.tanh(3.0 * lift))

        # 3) Threshold bonus: dense gradient through z=0.5 success line
        over_thr = max(-0.5, min(0.5, cube_z - 0.5))
        threshold_bonus = 0.6 * float(math.tanh(6.0 * over_thr))

        # 4) Proximity bonus: bounded 1/(1 + k*d^2), in (0, 0.6]
        proximity_bonus = 0.6 / (1.0 + 12.0 * dist_sq)

        # 5) XY alignment bonus
        xy_diff = cube_pos[:2] - target_pos[:2]
        xy_dist_sq = float(np.dot(xy_diff, xy_diff))
        xy_dist_sq = min(xy_dist_sq, 100.0)
        xy_bonus = 0.3 / (1.0 + 8.0 * xy_dist_sq)

        # 6) Action penalty (small L2)
        act_clipped = np.clip(act_arr, -2.0, 2.0)
        act_l2 = float(np.dot(act_clipped, act_clipped))
        action_penalty = -0.01 * min(act_l2, 14.0)

        # 7) Velocity penalty (small L2 on joint qvel)
        vel_l2 = float(np.dot(joint_vel, joint_vel))
        vel_penalty = -0.001 * min(vel_l2, 400.0)

        # 8) Staged milestone bonuses (smooth curriculum to success)
        stage_bonus = 0.0
        if cube_z > 0.45:
            stage_bonus += 0.3
        if cube_z > 0.5:
            stage_bonus += 0.7
        if cube_z > 0.5 and distance < 0.20:
            stage_bonus += 1.0
        if cube_z > 0.5 and distance < 0.15:
            stage_bonus += 2.0
        if success:
            stage_bonus += 5.0

        total = (
            anchor
            + lift_bonus
            + threshold_bonus
            + proximity_bonus
            + xy_bonus
            + action_penalty
            + vel_penalty
            + stage_bonus
        )

        # ---- Final safety net: finite + bounded ----
        if not np.isfinite(total):
            return -1.0
        return float(max(-20.0, min(20.0, float(total))))
    except:  # noqa: E722 - sandbox strips builtin Exception class
        return -1.0
