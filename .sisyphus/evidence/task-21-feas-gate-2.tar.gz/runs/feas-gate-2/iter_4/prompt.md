You are writing one dense reward function for a local MuJoCo physical AI task.

Task:
Franka pick-place anchor task. State-vector Franka pick-place target for Eureka-style reward search.

Reward signature:
reward=-distance(cube,target)+1_success; success=cube_z>0.5 and distance<0.1

Observation spec:
observation_space: ObsSpec(shape=(24,), dtype=dtype('float64'), low=None, high=None)

Action spec:
action_space: ActionSpec(shape=(7,), dtype=dtype('float64'), low=array([-1., -1., -1., -1., -1., -1., -1.]), high=array([1., 1., 1., 1., 1., 1., 1.]))

Prior attempts:
- attempt 0: metrics(mean_episode_reward=0, success_rate=0); reflection: **Iteration 0 summary (franka_pick):** The reward function itself compiled and was accepted by the training pipeline (`reward status: ok`), so the symbolic/syntactic layer is sound. However, evaluation crashed outright, meaning no rollouts produced valid success metrics — the 0% success rate reflects a hard failure, not a learning shortfall. The next attempt should focus on **diagnosing the crash before tuning shaping**: most commonly this is a tensor-shape/indexing mismatch, a NaN/Inf in a reward component (e. g. unbounded `1/distance` or `exp` term), or a missing observation key that the reward references.
- attempt 1: metrics(mean_episode_reward=0, success_rate=0); reflection: **Iteration 1 summary — franka_pick** The reward function itself was structurally valid (status `ok`), so the code compiled and the training loop accepted it — that's the only thing that worked. Evaluation crashed outright, which means the 0. 0 success rate carries no learning signal: we don't yet know whether the reward shape is good or bad, only that something in the eval path blew up. The most likely culprits are numerical instability in the reward (NaN/inf from divisions, logs, or unnormalized distances), tensor-shape or dtype mismatches between the reward output and what the evaluator expects, or out-of-range indexing on Franka's joint/end-effector state. The next attempt should **not** redesign the reward — it should add defensive guards (clamp denominators, `torch.
- attempt 2: metrics(mean_episode_reward=0, success_rate=0); reflection: **Iteration 2 — franka_pick summary** The reward function itself loaded and ran without errors (`reward status: ok`), so the signal definition is at least syntactically valid and exposes the expected interface. However, evaluation crashed mid-rollout and the policy produced 0% success, identical to the prior best — meaning we have no usable learning signal from this run and cannot tell whether the reward shape was actually guiding behavior. The crash is the blocking issue: a reward that triggers runtime faults (NaN/inf from divisions, unbounded exponentials, unguarded tensor ops, or referencing unavailable observation fields) will abort episodes before any pick can occur, masking reward quality entirely. **Next attempt should:** 1. Add numerical guards — clamp distances, use `torch.
- attempt 3: metrics(mean_episode_reward=1, success_rate=1); reflection: Iteration 3 of `franka_pick` converged to a perfect 1. 000 success rate with no reward errors and no evaluation failures, matching the running best. The reward shaping in this attempt clearly produced a learnable signal end-to-end — the policy reliably completes the pick, so there is no failure mode to diagnose here. Because success is already saturated, no change to the reward function is warranted on correctness grounds; further edits risk regressing a working solution. The next attempt should instead **freeze this reward as the new baseline** and shift effort to robustness: evaluate on harder variants (perturbed object poses, distractors, noisier observations) to confirm 1.

Context seed:
46

Emit exactly one fenced Python code block containing:

```python
def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    ...
```

Use only numpy, math, and physlab imports. Do not perform file, network, process, or random
side effects. The reward should be shaped for learning and return a finite float.
