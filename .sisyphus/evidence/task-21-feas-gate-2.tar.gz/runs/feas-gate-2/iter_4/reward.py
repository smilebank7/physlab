import numpy as np
import math


def reward_fn(obs: np.ndarray, action: np.ndarray, info: dict) -> float:
    # --- Defensive input sanitization (root cause of attempts 0-2 crashes) ---
    obs_arr = np.asarray(obs, dtype=np.float64).reshape(-1)
    act_arr = np.asarray(action, dtype=np.float64).reshape(-1)
    obs_arr = np.nan_to_num(obs_arr, nan=0.0, posinf=1e3, neginf=-1e3)
    act_arr = np.nan_to_num(act_arr, nan=0.0, posinf=1.0, neginf=-1.0)

    # --- Robust position extraction: prefer info dict, fall back to obs slots ---
    def _get_pos(keys, fallback):
        if isinstance(info, dict):
            for k in keys:
                if k in info:
                    try:
                        v = np.asarray(info[k], dtype=np.float64).reshape(-1)
                        if v.size >= 3 and np.all(np.isfinite(v[:3])):
                            return v[:3].astype(np.float64)
                    except Exception:
                        continue
        return np.asarray(fallback, dtype=np.float64).reshape(-1)[:3]

    n = obs_arr.size
    # Common 24-D Franka pick-place layout:
    # [0:7] arm qpos, [7:14] arm qvel, [14:17] cube pos,
    # [17:20] target pos, [20:23] ee pos, [23] gripper width
    cube_default = obs_arr[14:17] if n >= 17 else np.zeros(3)
    target_default = obs_arr[17:20] if n >= 20 else np.zeros(3)
    ee_default = obs_arr[20:23] if n >= 23 else cube_default

    cube_pos = _get_pos(("cube_pos", "object_pos", "block_pos", "obj_pos"), cube_default)
    target_pos = _get_pos(("target_pos", "goal_pos", "target", "goal"), target_default)
    ee_pos = _get_pos(("ee_pos", "eef_pos", "gripper_pos", "hand_pos", "tcp_pos"), ee_default)

    # --- Core distances (clipped to avoid runaway values) ---
    cube_to_target = float(np.clip(np.linalg.norm(cube_pos - target_pos), 0.0, 5.0))
    ee_to_cube = float(np.clip(np.linalg.norm(ee_pos - cube_pos), 0.0, 5.0))
    cube_z = float(np.clip(cube_pos[2], -2.0, 5.0))

    # --- Spec-mandated primary terms: -distance + 1_success ---
    place_reward = -cube_to_target
    success = (cube_z > 0.5) and (cube_to_target < 0.1)
    success_bonus = 1.0 if success else 0.0

    # --- Dense shaping (bounded, tanh-saturating, NaN-safe) ---
    # 1) Reach: gripper -> cube
    reach_shaping = 1.0 - math.tanh(5.0 * ee_to_cube)
    # 2) Place shaping: cube -> target (complements -distance with bounded signal)
    place_shaping = 1.0 - math.tanh(3.0 * cube_to_target)
    # 3) Lift: reward cube above table, gated by grasping proximity
    grasping = 1.0 if ee_to_cube < 0.08 else 0.0
    lift_progress = float(np.clip((cube_z - 0.05) / 0.45, 0.0, 1.0))
    lift_bonus = grasping * lift_progress
    # 4) Stage gate: only reward place-shaping once cube is lifted
    lifted = 1.0 if cube_z > 0.15 else 0.0
    place_shaping_gated = lifted * place_shaping

    # --- Mild action regularization (smoother policies, no NaN risk) ---
    action_cost = 1e-3 * float(np.sum(np.square(np.clip(act_arr, -1.0, 1.0))))

    # --- Combine: spec terms dominate, shaping provides curriculum ---
    reward = (
        place_reward
        + success_bonus
        + 0.25 * reach_shaping
        + 0.35 * place_shaping_gated
        + 0.50 * lift_bonus
        - action_cost
    )

    # --- Final safety: guarantee finite float ---
    if not math.isfinite(reward):
        return -1.0
    return float(np.clip(reward, -10.0, 10.0))