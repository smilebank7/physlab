# Eureka Franka Run

- best_iteration: 0
- best_success_rate: 1.000000

iteration | success_rate | wall_clock | reward_signature
0 | 1.0000 | 6.56s | 
1 | 1.0000 | 6.78s | 
2 | 1.0000 | 6.63s | 
3 | 1.0000 | 6.73s | 
4 | 1.0000 | 6.91s | 
